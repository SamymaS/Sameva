import { motion } from "motion/react";
import { ShoppingBag, Sparkles, Crown, Shield, Wand2, Heart, Zap } from "lucide-react";
import { useState } from "react";

export function Marketplace() {
  const [selectedRarity, setSelectedRarity] = useState("all");

  const rarityColors = {
    common: { bg: "from-gray-200 to-slate-200", border: "border-gray-300", glow: "shadow-gray-200/40", text: "text-gray-800" },
    rare: { bg: "from-blue-200 to-cyan-200", border: "border-blue-300", glow: "shadow-blue-200/50", text: "text-blue-800" },
    epic: { bg: "from-purple-200 to-pink-200", border: "border-purple-300", glow: "shadow-purple-200/50", text: "text-purple-800" },
    legendary: { bg: "from-amber-200 to-yellow-200", border: "border-amber-300", glow: "shadow-amber-200/60", text: "text-amber-800" },
  };

  const items = [
    {
      id: 1,
      name: "Couronne Céleste",
      rarity: "legendary",
      price: 5000,
      icon: Crown,
      description: "Augmente tous les gains d'XP de 25%",
      stats: "+25% XP"
    },
    {
      id: 2,
      name: "Aura Mystique",
      rarity: "epic",
      price: 2500,
      icon: Sparkles,
      description: "Effet visuel spectaculaire autour de l'avatar",
      stats: "Cosmétique"
    },
    {
      id: 3,
      name: "Bouclier de Persévérance",
      rarity: "rare",
      price: 1200,
      icon: Shield,
      description: "Protège une quête de l'échec",
      stats: "+1 Protection"
    },
    {
      id: 4,
      name: "Baguette d'Énergie",
      rarity: "epic",
      price: 3000,
      icon: Wand2,
      description: "Restaure instantanément l'énergie",
      stats: "+100 Énergie"
    },
    {
      id: 5,
      name: "Potion de Vitalité",
      rarity: "common",
      price: 300,
      icon: Heart,
      description: "Augmente la vitalité temporairement",
      stats: "+20 Vitalité"
    },
    {
      id: 6,
      name: "Éclair Foudroyant",
      rarity: "rare",
      price: 1500,
      icon: Zap,
      description: "Double les récompenses de la prochaine quête",
      stats: "x2 Récompenses"
    },
  ];

  const filteredItems = selectedRarity === "all" 
    ? items 
    : items.filter(item => item.rarity === selectedRarity);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f4fa] via-[#f0e8f8] to-[#e8e0f5] overflow-hidden relative">
      {/* Soft atmospheric background */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute top-20 left-20 w-96 h-96 bg-purple-300/15 rounded-full blur-[120px]"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{ duration: 6, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-20 right-20 w-96 h-96 bg-pink-300/15 rounded-full blur-[120px]"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{ duration: 6, repeat: Infinity }}
        />
      </div>

      {/* Header */}
      <div className="relative z-10 p-6">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-purple-900/70">
              Marché Mystique
            </h2>
            <p className="text-purple-700/60 mt-2">Échange ton or contre des objets magiques</p>
          </div>
          <div className="bg-gradient-to-r from-amber-100 to-yellow-100 px-6 py-3 rounded-2xl flex items-center gap-2 shadow-xl shadow-amber-200/50 border border-amber-200/50">
            <Sparkles className="w-5 h-5 text-amber-600" />
            <span className="text-lg text-amber-900">2,450</span>
          </div>
        </div>
      </div>

      {/* Rarity filters */}
      <div className="relative z-10 px-6 mt-6">
        <div className="flex gap-3 overflow-x-auto pb-2">
          <motion.button
            onClick={() => setSelectedRarity("all")}
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            className={`px-6 py-2 rounded-full whitespace-nowrap transition-all border-2 ${
              selectedRarity === "all"
                ? 'bg-gradient-to-r from-purple-200 to-pink-200 shadow-xl shadow-purple-200/50 border-purple-300/60 text-purple-900'
                : 'bg-white/60 border-purple-200/40 text-purple-700/70 shadow-lg shadow-purple-100/30'
            }`}
          >
            Tout
          </motion.button>
          <motion.button
            onClick={() => setSelectedRarity("common")}
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            className={`px-6 py-2 rounded-full whitespace-nowrap transition-all border-2 ${
              selectedRarity === "common"
                ? 'bg-gradient-to-r from-gray-200 to-slate-200 shadow-xl shadow-gray-200/50 border-gray-300/60 text-gray-900'
                : 'bg-white/60 border-gray-200/40 text-gray-700/70 shadow-lg shadow-gray-100/30'
            }`}
          >
            Commun
          </motion.button>
          <motion.button
            onClick={() => setSelectedRarity("rare")}
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            className={`px-6 py-2 rounded-full whitespace-nowrap transition-all border-2 ${
              selectedRarity === "rare"
                ? 'bg-gradient-to-r from-blue-200 to-cyan-200 shadow-xl shadow-blue-200/50 border-blue-300/60 text-blue-900'
                : 'bg-white/60 border-blue-200/40 text-blue-700/70 shadow-lg shadow-blue-100/30'
            }`}
          >
            Rare
          </motion.button>
          <motion.button
            onClick={() => setSelectedRarity("epic")}
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            className={`px-6 py-2 rounded-full whitespace-nowrap transition-all border-2 ${
              selectedRarity === "epic"
                ? 'bg-gradient-to-r from-purple-200 to-pink-200 shadow-xl shadow-purple-200/50 border-purple-300/60 text-purple-900'
                : 'bg-white/60 border-purple-200/40 text-purple-700/70 shadow-lg shadow-purple-100/30'
            }`}
          >
            Épique
          </motion.button>
          <motion.button
            onClick={() => setSelectedRarity("legendary")}
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            className={`px-6 py-2 rounded-full whitespace-nowrap transition-all border-2 ${
              selectedRarity === "legendary"
                ? 'bg-gradient-to-r from-amber-200 to-yellow-200 shadow-xl shadow-amber-200/50 border-amber-300/60 text-amber-900'
                : 'bg-white/60 border-amber-200/40 text-amber-700/70 shadow-lg shadow-amber-100/30'
            }`}
          >
            Légendaire
          </motion.button>
        </div>
      </div>

      {/* Items grid */}
      <div className="relative z-10 px-6 mt-8">
        <div className="grid grid-cols-2 gap-4 max-w-4xl mx-auto pb-32">
          {filteredItems.map((item, idx) => {
            const rarity = rarityColors[item.rarity as keyof typeof rarityColors];
            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className={`bg-white/70 backdrop-blur-xl border-2 ${rarity.border} rounded-3xl p-6 shadow-2xl ${rarity.glow} relative overflow-hidden`}
              >
                {/* Soft inner glow */}
                <div className={`absolute inset-0 bg-gradient-to-br ${rarity.bg} opacity-20`} />
                
                {/* Rarity badge */}
                <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs bg-gradient-to-r ${rarity.bg} shadow-lg capitalize border border-white/50 ${rarity.text}`}>
                  {item.rarity}
                </div>

                {/* Icon with soft halo */}
                <div className="relative mb-4">
                  <div className={`absolute inset-0 bg-gradient-to-br ${rarity.bg} opacity-30 rounded-2xl blur-2xl scale-150`} />
                  <div className={`relative w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br ${rarity.bg} flex items-center justify-center shadow-xl ${rarity.glow} border border-white/50`}>
                    <item.icon className={`w-10 h-10 ${rarity.text}`} />
                  </div>
                </div>

                {/* Name & description */}
                <h4 className={`text-center mb-2 relative ${rarity.text}`}>{item.name}</h4>
                <p className={`text-sm ${rarity.text.replace('800', '700/80')} text-center mb-3 relative`}>{item.description}</p>
                
                {/* Stats */}
                <div className={`bg-white/60 backdrop-blur-sm rounded-xl px-3 py-2 mb-4 text-center relative border border-${rarity.border.split('-')[1]}-200/40`}>
                  <span className={`text-xs ${rarity.text.replace('800', '700')}`}>{item.stats}</span>
                </div>

                {/* Price & buy button */}
                <motion.button
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className={`relative w-full bg-gradient-to-r ${rarity.bg} hover:opacity-90 ${rarity.text} py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg ${rarity.glow} transition-all border border-white/50 backdrop-blur-md`}
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{item.price.toLocaleString()} Or</span>
                </motion.button>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Featured item banner */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed bottom-20 left-6 right-6 z-20 max-w-4xl mx-auto"
      >
        <div className="bg-gradient-to-r from-amber-200 to-orange-200 rounded-3xl p-6 shadow-2xl shadow-amber-200/60 border-2 border-amber-300/60 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-100 to-yellow-100 flex items-center justify-center shadow-xl border border-amber-300/50 relative">
                <div className="absolute inset-0 bg-amber-300/30 rounded-2xl blur-xl scale-150" />
                <Crown className="w-8 h-8 text-amber-700 relative" />
              </div>
              <div>
                <h4 className="text-amber-900">Offre du jour</h4>
                <p className="text-sm text-amber-800/80 mt-1">Couronne Céleste -30% pour 24h</p>
              </div>
            </div>
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className="bg-white text-amber-700 px-6 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all border border-amber-300/50"
            >
              3,500 Or
            </motion.button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}