import { motion } from "motion/react";
import { Sparkles, Star, Heart, Zap, Settings, User } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface SanctuaryProps {
  onNavigate?: (page: string) => void;
}

export function Sanctuary({ onNavigate }: SanctuaryProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f4f8] via-[#f0e8f5] to-[#e8e0f0] overflow-hidden relative">
      {/* Soft atmospheric particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-purple-300/40 rounded-full"
            animate={{
              y: [Math.random() * 100 + "%", Math.random() * 100 + "%"],
              x: [Math.random() * 100 + "%", Math.random() * 100 + "%"],
              opacity: [0.1, 0.4, 0.1],
              scale: [1, 2, 1],
            }}
            transition={{
              duration: Math.random() * 8 + 5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>

      {/* Header with interactive buttons */}
      <div className="relative z-10 p-6 flex justify-between items-start">
        <div>
          <h3 className="text-purple-900/70">Sanctuaire</h3>
          <p className="text-sm text-purple-700/60 mt-1">Ton refuge mystique</p>
        </div>
        <div className="flex gap-3 items-center">
          {/* Profile button */}
          <motion.button
            whileHover={{ scale: 1.1, y: -2 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => onNavigate?.('profile')}
            className="w-10 h-10 rounded-full bg-white/70 backdrop-blur-md border border-purple-200/50 flex items-center justify-center shadow-lg shadow-purple-100/40 text-purple-600 hover:bg-purple-100/70 transition-colors"
          >
            <User className="w-5 h-5" />
          </motion.button>
          
          {/* Settings button */}
          <motion.button
            whileHover={{ scale: 1.1, y: -2, rotate: 90 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => onNavigate?.('settings')}
            className="w-10 h-10 rounded-full bg-white/70 backdrop-blur-md border border-purple-200/50 flex items-center justify-center shadow-lg shadow-purple-100/40 text-purple-600 hover:bg-purple-100/70 transition-colors"
          >
            <Settings className="w-5 h-5" />
          </motion.button>
          
          <div className="bg-gradient-to-br from-amber-100 to-yellow-100 px-4 py-2 rounded-full flex items-center gap-2 shadow-lg shadow-amber-200/60 border border-amber-200/50">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span className="text-amber-800">2,450</span>
          </div>
          <div className="bg-gradient-to-br from-purple-100 to-pink-100 px-4 py-2 rounded-full flex items-center gap-2 shadow-lg shadow-purple-200/60 border border-purple-200/50">
            <Star className="w-4 h-4 text-purple-600" />
            <span className="text-purple-800">Niv. 12</span>
          </div>
        </div>
      </div>

      {/* Button to create quest */}
      <div className="relative z-10 px-6 mt-4">
        <motion.button
          whileHover={{ scale: 1.02, y: -2 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onNavigate?.('quests')}
          className="w-full max-w-2xl mx-auto bg-white/60 backdrop-blur-md border-2 border-purple-200/50 rounded-3xl p-4 shadow-xl shadow-purple-100/40 flex items-center justify-center gap-2 text-purple-800 hover:bg-purple-50/60 transition-colors"
        >
          <span>Créer une nouvelle quête</span>
        </motion.button>
      </div>

      {/* Main sanctuary area */}
      <div className="relative z-10 flex flex-col items-center mt-8 px-6">
        {/* Avatar container with soft glow - CLICKABLE */}
        <motion.button
          className="relative"
          onClick={() => onNavigate?.('customization')}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          animate={{
            y: [0, -15, 0],
          }}
          transition={{
            y: {
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut",
            }
          }}
        >
          {/* Multiple soft glow layers */}
          <div className="absolute inset-0 bg-gradient-to-b from-purple-300/30 via-pink-300/30 to-blue-300/30 rounded-full blur-[80px] scale-[2.5]" />
          <div className="absolute inset-0 bg-gradient-to-b from-purple-200/40 via-pink-200/40 to-blue-200/40 rounded-full blur-[60px] scale-[2]" />
          <div className="absolute inset-0 bg-gradient-to-b from-purple-100/50 via-pink-100/50 to-blue-100/50 rounded-full blur-[40px] scale-[1.5]" />
          
          {/* Avatar */}
          <div className="relative w-56 h-56 rounded-full overflow-hidden border-4 border-white/80 shadow-2xl shadow-purple-300/40 hover:border-purple-200/80 transition-colors">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1759471623747-02ffce888005?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwc2FuY3R1YXJ5JTIwbXlzdGljYWx8ZW58MXx8fHwxNzYzMjM1OTIwfDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Avatar"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-purple-300/20 to-transparent" />
            
            {/* Edit indicator on hover */}
            <div className="absolute inset-0 bg-purple-500/0 hover:bg-purple-500/20 transition-colors flex items-center justify-center opacity-0 hover:opacity-100">
              <div className="bg-white/90 px-4 py-2 rounded-full text-purple-800 text-sm">
                Modifier
              </div>
            </div>
          </div>

          {/* Soft level badge */}
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-purple-200/90 to-pink-200/90 backdrop-blur-md px-5 py-2 rounded-full border-2 border-white/60 shadow-xl shadow-purple-200/50">
            <span className="text-sm text-purple-800">Mystique Niveau 12</span>
          </div>
        </motion.button>

        {/* Character name */}
        <h2 className="mt-10 text-center text-purple-900/80">
          Aventurier Céleste
        </h2>

        {/* Experience bar */}
        <div className="w-full max-w-md mt-6">
          <div className="flex justify-between text-sm text-purple-700/70 mb-2">
            <span>Expérience</span>
            <span>1,850 / 2,500 XP</span>
          </div>
          <div className="h-4 bg-white/70 backdrop-blur-sm rounded-full overflow-hidden border border-purple-200/50 shadow-inner">
            <motion.div
              className="h-full bg-gradient-to-r from-purple-300 via-pink-300 to-purple-300 shadow-lg shadow-purple-300/50 relative"
              initial={{ width: 0 }}
              animate={{ width: "74%" }}
              transition={{ duration: 1, delay: 0.5 }}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-white/30 to-transparent" />
            </motion.div>
          </div>
        </div>

        {/* Companion with ethereal glow - CLICKABLE */}
        <motion.button
          className="mt-16 relative"
          onClick={() => onNavigate?.('customization')}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          animate={{
            rotate: [0, 3, -3, 0],
          }}
          transition={{
            rotate: {
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
            }
          }}
        >
          {/* Ethereal glow layers */}
          <div className="absolute inset-0 bg-cyan-200/30 rounded-full blur-[60px] scale-[2.5]" />
          <div className="absolute inset-0 bg-blue-200/40 rounded-full blur-[40px] scale-[2]" />
          
          <div className="relative w-36 h-36 rounded-full overflow-hidden border-3 border-white/80 shadow-2xl shadow-cyan-200/40 hover:border-cyan-200/80 transition-colors">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1720466780959-aed3e2d5ba83?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXN0aWNhbCUyMGNyZWF0dXJlJTIwc3Bpcml0dWFsfGVufDF8fHx8MTc2MzIzNTkyMHww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Companion"
              className="w-full h-full object-cover opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-cyan-200/30 to-transparent" />
          </div>
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-cyan-100/90 backdrop-blur-md px-4 py-1 rounded-full border border-white/60 text-sm whitespace-nowrap shadow-lg shadow-cyan-200/40 text-cyan-800">
            Esprit Lunaire
          </div>
        </motion.button>

        {/* Stats with soft cards */}
        <div className="grid grid-cols-3 gap-4 mt-16 w-full max-w-md">
          <motion.div
            className="bg-white/60 backdrop-blur-md border border-red-200/50 rounded-3xl p-5 text-center shadow-xl shadow-red-100/50 relative overflow-hidden"
            whileHover={{ scale: 1.05, y: -4 }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-red-100/40 to-pink-100/40" />
            <div className="relative">
              <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br from-red-200 to-pink-200 flex items-center justify-center shadow-lg shadow-red-200/50">
                <Heart className="w-6 h-6 text-red-600" />
              </div>
              <div className="text-red-800/70 text-sm">Vitalité</div>
              <div className="text-xl text-red-900 mt-1">85</div>
            </div>
          </motion.div>
          
          <motion.div
            className="bg-white/60 backdrop-blur-md border border-blue-200/50 rounded-3xl p-5 text-center shadow-xl shadow-blue-100/50 relative overflow-hidden"
            whileHover={{ scale: 1.05, y: -4 }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-100/40 to-cyan-100/40" />
            <div className="relative">
              <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br from-blue-200 to-cyan-200 flex items-center justify-center shadow-lg shadow-blue-200/50">
                <Zap className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-blue-800/70 text-sm">Énergie</div>
              <div className="text-xl text-blue-900 mt-1">92</div>
            </div>
          </motion.div>
          
          <motion.div
            className="bg-white/60 backdrop-blur-md border border-purple-200/50 rounded-3xl p-5 text-center shadow-xl shadow-purple-100/50 relative overflow-hidden"
            whileHover={{ scale: 1.05, y: -4 }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-100/40 to-pink-100/40" />
            <div className="relative">
              <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br from-purple-200 to-pink-200 flex items-center justify-center shadow-lg shadow-purple-200/50">
                <Sparkles className="w-6 h-6 text-purple-600" />
              </div>
              <div className="text-purple-800/70 text-sm">Magie</div>
              <div className="text-xl text-purple-900 mt-1">78</div>
            </div>
          </motion.div>
        </div>

        {/* Daily quests with soft styling */}
        <div className="mt-12 w-full max-w-md bg-white/70 backdrop-blur-md border border-purple-200/50 rounded-3xl p-6 mb-24 shadow-xl shadow-purple-100/30">
          <div className="flex justify-between items-center mb-5">
            <h4 className="text-purple-900/80">Quêtes du jour</h4>
            <span className="text-sm bg-purple-100/80 text-purple-700 px-4 py-1 rounded-full border border-purple-200/50">3/5 complétées</span>
          </div>
          <div className="space-y-3">
            {[
              { name: "Méditation matinale", completed: true },
              { name: "Entraînement physique", completed: true },
              { name: "Lecture inspirante", completed: true },
              { name: "Projet créatif", completed: false },
              { name: "Connexion sociale", completed: false },
            ].map((quest, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shadow-sm ${quest.completed ? 'bg-green-200 border-green-300 shadow-green-200/50' : 'bg-white border-purple-300'}`}>
                  {quest.completed && <span className="text-xs text-green-700">✓</span>}
                </div>
                <span className={quest.completed ? 'text-purple-600/60 line-through' : 'text-purple-800'}>{quest.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}