import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Star, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Summoning() {
  const [isSummoning, setIsSummoning] = useState(false);
  const [summonedItem, setSummonedItem] = useState<any>(null);

  const summonItems = [
    { name: "Esprit du Feu", rarity: "legendary", type: "companion" },
    { name: "Aura Céleste", rarity: "epic", type: "effect" },
    { name: "Gemme d'Énergie", rarity: "rare", type: "item" },
    { name: "Potion Mystique", rarity: "common", type: "item" },
  ];

  const handleSummon = () => {
    setIsSummoning(true);
    setTimeout(() => {
      const randomItem = summonItems[Math.floor(Math.random() * summonItems.length)];
      setSummonedItem(randomItem);
      setIsSummoning(false);
    }, 3000);
  };

  const handleClose = () => {
    setSummonedItem(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1828] via-[#252033] to-[#2a2438] overflow-hidden relative">
      {/* Dark mystical background with layers */}
      <div className="absolute inset-0">
        {/* Dark vignette */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/40" />
        
        {/* Floating mystical particles */}
        {[...Array(60)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: Math.random() * 3 + 1 + 'px',
              height: Math.random() * 3 + 1 + 'px',
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              background: i % 3 === 0 ? '#a78bca' : i % 3 === 1 ? '#7ba5d6' : '#daa5c0',
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0, 0.6, 0],
              scale: [0, 1, 0],
            }}
            transition={{
              duration: Math.random() * 4 + 3,
              repeat: Infinity,
              delay: Math.random() * 3,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <div className="relative z-10 p-6 flex justify-between items-center">
        <button className="text-[#c9b8a8]/60 hover:text-[#c9b8a8] transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h2 className="text-[#c9b8a8] tracking-[0.3em]">
          SAMEVA
        </h2>
        <div className="text-[#c9b8a8]/60 text-sm tracking-widest">
          INVOCATION
        </div>
      </div>

      {/* Main portal architecture */}
      <div className="relative z-10 flex flex-col items-center justify-center mt-8 px-6">
        {/* Architectural portal structure */}
        <div className="relative">
          {/* Massive ethereal glow behind portal */}
          <motion.div
            className="absolute inset-0 rounded-full blur-[150px]"
            style={{
              width: "600px",
              height: "700px",
              left: "-150px",
              top: "-100px",
              background: "radial-gradient(circle, rgba(167, 139, 202, 0.3) 0%, rgba(123, 165, 214, 0.2) 30%, rgba(218, 165, 192, 0.1) 60%, transparent 100%)",
            }}
            animate={{
              scale: [1, 1.1, 1],
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{ duration: 6, repeat: Infinity }}
          />

          {/* Portal frame container */}
          <div className="relative w-[320px] h-[480px]">
            {/* Left column */}
            <div className="absolute left-0 top-0 w-16 h-full">
              <div className="w-full h-full bg-gradient-to-b from-[#3a3544] via-[#2e2838] to-[#3a3544] rounded-lg shadow-2xl relative">
                <div className="absolute inset-0 bg-gradient-to-r from-white/5 to-transparent rounded-lg" />
                {/* Column segments */}
                <div className="absolute top-0 left-0 right-0 h-16 border-b border-[#4a4454]" />
                <div className="absolute bottom-0 left-0 right-0 h-16 border-t border-[#4a4454]" />
                {/* Soft glow on column */}
                <div className="absolute -right-2 top-1/2 -translate-y-1/2 w-8 h-64 bg-blue-400/10 blur-2xl" />
              </div>
            </div>

            {/* Right column */}
            <div className="absolute right-0 top-0 w-16 h-full">
              <div className="w-full h-full bg-gradient-to-b from-[#3a3544] via-[#2e2838] to-[#3a3544] rounded-lg shadow-2xl relative">
                <div className="absolute inset-0 bg-gradient-to-l from-white/5 to-transparent rounded-lg" />
                {/* Column segments */}
                <div className="absolute top-0 left-0 right-0 h-16 border-b border-[#4a4454]" />
                <div className="absolute bottom-0 left-0 right-0 h-16 border-t border-[#4a4454]" />
                {/* Soft glow on column */}
                <div className="absolute -left-2 top-1/2 -translate-y-1/2 w-8 h-64 bg-blue-400/10 blur-2xl" />
              </div>
            </div>

            {/* Arch top */}
            <div className="absolute top-0 left-8 right-8 h-32">
              <svg viewBox="0 0 240 128" className="w-full h-full">
                <path
                  d="M 0 128 L 0 64 Q 0 0, 64 0 L 176 0 Q 240 0, 240 64 L 240 128"
                  fill="url(#archGradient)"
                  stroke="#4a4454"
                  strokeWidth="2"
                />
                <defs>
                  <linearGradient id="archGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#3a3544" />
                    <stop offset="50%" stopColor="#2e2838" />
                    <stop offset="100%" stopColor="#3a3544" />
                  </linearGradient>
                </defs>
              </svg>
              {/* Arch glow */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-24 bg-purple-400/10 blur-3xl" />
            </div>

            {/* Portal energy/vortex */}
            <div className="absolute top-20 left-16 right-16 bottom-8 overflow-hidden rounded-t-[100px]">
              {/* Cosmic vortex background */}
              <div className="absolute inset-0 bg-gradient-to-b from-[#2a3a6e] via-[#4a4a8e] to-[#6a5a9e]">
                {/* Vortex spiral effect */}
                <motion.div
                  className="absolute inset-0"
                  style={{
                    background: "radial-gradient(ellipse at center, rgba(123, 165, 214, 0.4) 0%, rgba(167, 139, 202, 0.3) 30%, rgba(218, 165, 192, 0.2) 60%, transparent 80%)",
                  }}
                  animate={{
                    rotate: 360,
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    rotate: { duration: 20, repeat: Infinity, ease: "linear" },
                    scale: { duration: 4, repeat: Infinity },
                  }}
                />
                
                {/* Stars in portal */}
                {[...Array(30)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-1 h-1 bg-white rounded-full"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                    }}
                    animate={{
                      opacity: [0, 1, 0],
                      scale: [0, 1.5, 0],
                    }}
                    transition={{
                      duration: Math.random() * 2 + 1,
                      repeat: Infinity,
                      delay: Math.random() * 2,
                    }}
                  />
                ))}

                {/* Central bright vortex core */}
                <motion.div
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full"
                  style={{
                    background: "radial-gradient(circle, rgba(255, 255, 255, 0.8) 0%, rgba(167, 200, 255, 0.4) 30%, transparent 70%)",
                  }}
                  animate={{
                    scale: [1, 1.3, 1],
                    opacity: [0.6, 1, 0.6],
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                />

                {/* Swirling energy particles when summoning */}
                {isSummoning && (
                  <>
                    {[...Array(40)].map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute w-2 h-2 bg-cyan-300 rounded-full"
                        style={{
                          left: "50%",
                          top: "50%",
                        }}
                        animate={{
                          x: Math.cos((i / 40) * Math.PI * 2) * 150,
                          y: Math.sin((i / 40) * Math.PI * 2) * 150,
                          opacity: [1, 0],
                          scale: [1, 0],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: (i / 40) * 0.5,
                        }}
                      />
                    ))}
                  </>
                )}
              </div>

              {/* Soft light overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#2a2438]/60 via-transparent to-transparent pointer-events-none" />
            </div>

            {/* Ethereal companion/spirit */}
            <motion.div
              className="absolute bottom-24 right-20 w-20 h-20 z-10"
              animate={{
                y: [0, -15, 0],
                x: [0, 5, 0],
                opacity: [0.7, 1, 0.7],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              {/* Spirit glow */}
              <div className="absolute inset-0 bg-cyan-400/40 rounded-full blur-3xl scale-150" />
              
              {/* Spirit creature (fox-like) */}
              <div className="relative w-full h-full">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1720466780959-aed3e2d5ba83?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXN0aWNhbCUyMGNyZWF0dXJlJTIwc3Bpcml0dWFsfGVufDF8fHx8MTc2MzIzNTkyMHww&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Spirit"
                  className="w-full h-full object-cover rounded-full opacity-80"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-cyan-400/30 to-transparent rounded-full" />
              </div>
            </motion.div>

            {/* Platform/base */}
            <div className="absolute bottom-0 left-8 right-8 h-16">
              <div className="w-full h-full bg-gradient-to-b from-[#3a3544] to-[#2a2434] rounded-lg shadow-2xl relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-white/5 to-transparent" />
                {/* Mystical circle on platform */}
                <div className="absolute top-2 left-1/2 -translate-x-1/2 w-32 h-2">
                  <motion.div
                    className="w-full h-full rounded-full"
                    style={{
                      background: "radial-gradient(ellipse, rgba(218, 165, 192, 0.4) 0%, transparent 70%)",
                    }}
                    animate={{
                      opacity: [0.3, 0.6, 0.3],
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Decorative floating stars */}
          <motion.div
            className="absolute -top-8 -right-12 text-[#c9b8a8]/40"
            animate={{
              rotate: [0, 360],
              opacity: [0.3, 0.7, 0.3],
            }}
            transition={{ duration: 8, repeat: Infinity }}
          >
            <Star className="w-8 h-8" fill="currentColor" />
          </motion.div>
          <motion.div
            className="absolute top-16 -left-16 text-[#a78bca]/40"
            animate={{
              rotate: [360, 0],
              opacity: [0.3, 0.7, 0.3],
              scale: [0.8, 1.2, 0.8],
            }}
            transition={{ duration: 6, repeat: Infinity }}
          >
            <Star className="w-6 h-6" fill="currentColor" />
          </motion.div>
        </div>

        {/* Summon button */}
        <motion.button
          onClick={handleSummon}
          disabled={isSummoning}
          whileHover={!isSummoning ? { scale: 1.05, y: -4 } : {}}
          whileTap={!isSummoning ? { scale: 0.98 } : {}}
          className={`mt-12 px-20 py-5 rounded-full shadow-2xl transition-all backdrop-blur-md border-2 relative overflow-hidden ${
            isSummoning
              ? 'bg-[#8a7a6a]/50 border-[#9a8a7a]/50 text-[#c9b8a8]/60 cursor-not-allowed'
              : 'bg-gradient-to-r from-[#c9b8a8] to-[#b8a898] border-[#d9c8b8]/60 text-[#3a2a1a] hover:from-[#d9c8b8] hover:to-[#c8b8a8]'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-white/20 to-transparent" />
          <span className="relative tracking-[0.2em]">{isSummoning ? 'INVOQUER...' : 'SUMMON'}</span>
        </motion.button>

        {/* Cost and info */}
        <div className="mt-8 text-center mb-24">
          <div className="text-[#c9b8a8]/60 text-sm mb-6">
            100 💎 par invocation
          </div>
        </div>
      </div>

      {/* Summoned item reveal modal */}
      <AnimatePresence>
        {summonedItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-6"
            onClick={handleClose}
          >
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              exit={{ scale: 0, rotate: 180 }}
              className="bg-gradient-to-b from-[#3a3544] to-[#2e2838] border-4 border-[#c9b8a8]/40 rounded-[3rem] p-10 max-w-md w-full text-center shadow-2xl relative"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Soft glow behind */}
              <div className="absolute inset-0 bg-gradient-to-b from-purple-400/20 to-pink-400/20 rounded-[3rem] blur-[60px] scale-110 -z-10" />
              
              {/* Sparkles around */}
              {[...Array(12)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute"
                  animate={{
                    opacity: [0, 1, 0],
                    scale: [0, 1, 0],
                    x: Math.cos(i * 30 * Math.PI / 180) * 150,
                    y: Math.sin(i * 30 * Math.PI / 180) * 150,
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    delay: i * 0.1,
                  }}
                  style={{
                    left: "50%",
                    top: "50%",
                  }}
                >
                  <Star className="w-4 h-4 text-[#c9b8a8]/60" fill="currentColor" />
                </motion.div>
              ))}

              <motion.div
                animate={{
                  rotate: [0, 360],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "linear",
                }}
                className="w-36 h-36 mx-auto mb-8 rounded-3xl bg-gradient-to-br from-purple-400/40 to-pink-400/40 flex items-center justify-center shadow-2xl border border-[#c9b8a8]/20 relative"
              >
                <div className="absolute inset-0 bg-gradient-to-t from-white/10 to-transparent rounded-3xl" />
                <Sparkles className="w-16 h-16 text-[#c9b8a8]" />
              </motion.div>

              <div className="inline-block px-5 py-2 rounded-full text-sm mb-4 bg-gradient-to-r from-purple-400/30 to-pink-400/30 text-[#c9b8a8] capitalize border border-[#c9b8a8]/30">
                {summonedItem.rarity}
              </div>

              <h2 className="mb-4 text-[#c9b8a8]">{summonedItem.name}</h2>
              <p className="text-[#c9b8a8]/70 mb-8">
                {summonedItem.type === 'companion' ? 'Un nouveau compagnon t\'accompagne !' : 
                 summonedItem.type === 'effect' ? 'Un nouvel effet visuel débloqué !' :
                 'Un nouvel objet ajouté à ton inventaire !'}
              </p>

              <motion.button
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleClose}
                className="px-10 py-4 rounded-full bg-gradient-to-r from-[#c9b8a8] to-[#b8a898] text-[#3a2a1a] shadow-xl border border-[#d9c8b8]/50 backdrop-blur-md"
              >
                Fantastique !
              </motion.button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
