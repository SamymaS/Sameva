import { motion } from "motion/react";
import { Gamepad2, Star, Trophy, Zap, ArrowLeft } from "lucide-react";
import { useState, useEffect } from "react";

export function MiniGame() {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isPlaying, setIsPlaying] = useState(false);
  const [targets, setTargets] = useState<Array<{ id: number; x: number; y: number }>>([]);
  const [selectedGame, setSelectedGame] = useState<string | null>(null);

  useEffect(() => {
    if (isPlaying && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      setIsPlaying(false);
    }
  }, [isPlaying, timeLeft]);

  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setTargets((prev) => [
          ...prev.slice(-4),
          {
            id: Date.now(),
            x: Math.random() * 80 + 10,
            y: Math.random() * 60 + 10,
          },
        ]);
      }, 800);
      return () => clearInterval(interval);
    }
  }, [isPlaying]);

  const handleStart = () => {
    setScore(0);
    setTimeLeft(30);
    setTargets([]);
    setIsPlaying(true);
  };

  const handleTargetClick = (id: number) => {
    setScore(score + 10);
    setTargets(targets.filter((t) => t.id !== id));
  };

  const games = [
    {
      id: "platformer",
      name: "Platformer",
      icon: "🏃",
      xp: 200,
      gold: 150,
      background: "from-cyan-600/80 to-blue-600/80",
    },
    {
      id: "puzzle",
      name: "Puzzle runique",
      icon: "🧩",
      xp: 200,
      gold: 150,
      background: "from-purple-600/80 to-indigo-600/80",
    },
    {
      id: "idle",
      name: "Idle compagnon",
      icon: "🌱",
      xp: 200,
      gold: 150,
      background: "from-green-600/80 to-emerald-600/80",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a1a2e] via-[#16213e] to-[#0f3460] overflow-hidden relative">
      {/* Dark fantasy forest background */}
      <div className="absolute inset-0">
        {/* Sky with stars */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a1a2e] via-[#16213e] to-[#1a2940]" />
        
        {/* Stars */}
        {[...Array(100)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-white"
            style={{
              width: Math.random() * 2 + 1 + 'px',
              height: Math.random() * 2 + 1 + 'px',
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 60}%`,
            }}
            animate={{
              opacity: [0.2, 1, 0.2],
              scale: [0.8, 1.2, 0.8],
            }}
            transition={{
              duration: Math.random() * 3 + 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}

        {/* Glowing stars (bigger) */}
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={`glow-${i}`}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 50}%`,
            }}
            animate={{
              opacity: [0.4, 1, 0.4],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: Math.random() * 2 + 1,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          >
            <Star className="w-4 h-4 text-cyan-300" fill="currentColor" />
          </motion.div>
        ))}

        {/* Left tree silhouette */}
        <div className="absolute bottom-0 left-0 w-64 h-96 opacity-60">
          <div className="absolute bottom-0 left-8 w-32 h-80 bg-gradient-to-t from-[#1a3a2e] to-transparent rounded-t-full" />
          <div className="absolute bottom-0 left-0 w-48 h-64 bg-gradient-to-t from-[#0f2a1e] to-transparent rounded-t-[100px] opacity-70" />
          {/* Tree foliage circles */}
          <div className="absolute top-20 left-12 w-40 h-40 bg-[#2a5a4e] rounded-full opacity-80 blur-sm" />
          <div className="absolute top-32 left-8 w-32 h-32 bg-[#1a4a3e] rounded-full opacity-70 blur-sm" />
          {/* Mystical fireflies in tree */}
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-yellow-300 rounded-full"
              style={{
                left: `${30 + Math.random() * 40}%`,
                top: `${30 + Math.random() * 30}%`,
              }}
              animate={{
                opacity: [0, 1, 0],
                y: [0, -10, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.4,
              }}
            />
          ))}
        </div>

        {/* Right tree silhouette */}
        <div className="absolute bottom-0 right-0 w-64 h-96 opacity-60">
          <div className="absolute bottom-0 right-8 w-32 h-80 bg-gradient-to-t from-[#1a3a2e] to-transparent rounded-t-full" />
          <div className="absolute bottom-0 right-0 w-48 h-64 bg-gradient-to-t from-[#0f2a1e] to-transparent rounded-t-[100px] opacity-70" />
          {/* Tree foliage circles */}
          <div className="absolute top-20 right-12 w-40 h-40 bg-[#2a5a4e] rounded-full opacity-80 blur-sm" />
          <div className="absolute top-32 right-8 w-32 h-32 bg-[#1a4a3e] rounded-full opacity-70 blur-sm" />
          {/* Mystical fireflies */}
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-yellow-300 rounded-full"
              style={{
                right: `${30 + Math.random() * 40}%`,
                top: `${30 + Math.random() * 30}%`,
              }}
              animate={{
                opacity: [0, 1, 0],
                y: [0, -10, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.4,
              }}
            />
          ))}
        </div>

        {/* Mystical fog/mist at bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-[#1a3a5e]/60 via-[#1a3a5e]/30 to-transparent" />
      </div>

      {/* Header */}
      <div className="relative z-10 p-6 flex justify-between items-center">
        <button className="text-cyan-300/60 hover:text-cyan-300 transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h2 className="text-[#f4d58d] tracking-[0.2em]">
          MINI-JEUX
        </h2>
        <div className="w-6" />
      </div>

      {/* Subtitle */}
      <div className="relative z-10 text-center mb-8">
        <h3 className="text-cyan-300/80 tracking-wider">Le Jardin des Épreuves</h3>
      </div>

      {/* Game selection or active game */}
      {!isPlaying && timeLeft === 30 ? (
        // Game menu
        <div className="relative z-10 px-6 mt-8">
          <div className="max-w-2xl mx-auto grid grid-cols-2 gap-6 mb-24">
            {/* First two games in a row */}
            {games.slice(0, 2).map((game, idx) => (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="relative group cursor-pointer"
              >
                {/* Card glow */}
                <div className={`absolute inset-0 bg-gradient-to-br ${game.background} rounded-3xl blur-xl opacity-60 group-hover:opacity-80 transition-opacity`} />
                
                {/* Card */}
                <div className={`relative bg-gradient-to-br ${game.background} backdrop-blur-xl border-2 border-white/20 rounded-3xl p-6 shadow-2xl overflow-hidden`}>
                  {/* Inner glow overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-white/10 to-transparent" />
                  
                  {/* Game icon/preview area */}
                  <div className="relative aspect-square bg-gradient-to-br from-white/20 to-white/5 rounded-2xl mb-4 flex items-center justify-center border border-white/20 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-blue-400/20" />
                    <div className="text-6xl relative z-10">{game.icon}</div>
                    {/* Sparkles */}
                    {[...Array(8)].map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute w-1 h-1 bg-white rounded-full"
                        style={{
                          left: `${Math.random() * 100}%`,
                          top: `${Math.random() * 100}%`,
                        }}
                        animate={{
                          opacity: [0, 1, 0],
                          scale: [0, 1.5, 0],
                        }}
                        transition={{
                          duration: 1.5,
                          repeat: Infinity,
                          delay: i * 0.2,
                        }}
                      />
                    ))}
                  </div>

                  {/* Game name */}
                  <h4 className="text-white text-center mb-3 relative">{game.name}</h4>

                  {/* Rewards */}
                  <div className="flex items-center justify-center gap-4 text-white/90 relative">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-300" fill="currentColor" />
                      <span className="text-sm">{game.xp}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-4 h-4 bg-amber-400 rounded-full flex items-center justify-center text-xs">💰</div>
                      <span className="text-sm">{game.gold}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Third game centered below */}
            <div className="col-span-2 flex justify-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="relative group cursor-pointer w-1/2"
              >
                {/* Card glow */}
                <div className={`absolute inset-0 bg-gradient-to-br ${games[2].background} rounded-3xl blur-xl opacity-60 group-hover:opacity-80 transition-opacity`} />
                
                {/* Card */}
                <div className={`relative bg-gradient-to-br ${games[2].background} backdrop-blur-xl border-2 border-white/20 rounded-3xl p-6 shadow-2xl overflow-hidden`}>
                  {/* Inner glow overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-white/10 to-transparent" />
                  
                  {/* Game icon/preview area */}
                  <div className="relative aspect-square bg-gradient-to-br from-white/20 to-white/5 rounded-2xl mb-4 flex items-center justify-center border border-white/20 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-green-400/20 to-emerald-400/20" />
                    <div className="text-6xl relative z-10">{games[2].icon}</div>
                    {/* Sparkles */}
                    {[...Array(8)].map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute w-1 h-1 bg-white rounded-full"
                        style={{
                          left: `${Math.random() * 100}%`,
                          top: `${Math.random() * 100}%`,
                        }}
                        animate={{
                          opacity: [0, 1, 0],
                          scale: [0, 1.5, 0],
                        }}
                        transition={{
                          duration: 1.5,
                          repeat: Infinity,
                          delay: i * 0.2,
                        }}
                      />
                    ))}
                  </div>

                  {/* Game name */}
                  <h4 className="text-white text-center mb-3 relative">{games[2].name}</h4>

                  {/* Rewards */}
                  <div className="flex items-center justify-center gap-4 text-white/90 relative">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-300" fill="currentColor" />
                      <span className="text-sm">{games[2].xp}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-4 h-4 bg-amber-400 rounded-full flex items-center justify-center text-xs">💰</div>
                      <span className="text-sm">{games[2].gold}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      ) : (
        // Active game (simplified for now)
        <div className="relative z-10 px-6 mt-8">
          <div className="max-w-4xl mx-auto">
            {/* Game HUD */}
            <div className="flex justify-between items-center mb-6">
              <div className="bg-[#16213e]/80 backdrop-blur-md border border-cyan-400/30 rounded-2xl px-6 py-3 shadow-lg">
                <div className="text-sm text-cyan-300/70">Score</div>
                <div className="text-2xl text-cyan-200">{score}</div>
              </div>
              <div className="bg-[#16213e]/80 backdrop-blur-md border border-cyan-400/30 rounded-2xl px-6 py-3 shadow-lg">
                <div className="text-sm text-cyan-300/70">Temps</div>
                <div className="text-2xl text-cyan-200">{timeLeft}s</div>
              </div>
            </div>

            {/* Game area */}
            <div className="h-[500px] bg-[#16213e]/60 backdrop-blur-xl border-2 border-cyan-400/30 rounded-3xl relative overflow-hidden shadow-2xl mb-24">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-600/10 to-blue-600/10" />
              {isPlaying && targets.map((target) => (
                <motion.div
                  key={target.id}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  className="absolute w-16 h-16 cursor-pointer"
                  style={{ left: `${target.x}%`, top: `${target.y}%` }}
                  onClick={() => handleTargetClick(target.id)}
                >
                  <motion.div
                    animate={{
                      scale: [1, 1.2, 1],
                      rotate: [0, 180, 360],
                    }}
                    transition={{ duration: 0.8 }}
                    className="w-full h-full rounded-full bg-gradient-to-br from-cyan-400 to-blue-400 shadow-xl shadow-cyan-400/50 flex items-center justify-center border-2 border-white/60 relative"
                  >
                    <div className="absolute inset-0 bg-cyan-400/30 rounded-full blur-xl scale-150" />
                    <Star className="w-8 h-8 text-white relative" />
                  </motion.div>
                </motion.div>
              ))}

              {!isPlaying && timeLeft === 0 && (
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="absolute inset-0 flex flex-col items-center justify-center bg-[#0a1a2e]/90 backdrop-blur-md"
                >
                  <Trophy className="w-20 h-20 text-cyan-400 mb-4" />
                  <h2 className="mb-2 text-cyan-200">Partie terminée !</h2>
                  <div className="text-4xl mb-4 text-cyan-300">{score} points</div>
                  <div className="mb-6 text-cyan-300/80">+{Math.floor(score / 10)} XP gagnés</div>
                  <div className="flex gap-4">
                    <motion.button
                      onClick={handleStart}
                      whileHover={{ scale: 1.05, y: -2 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-8 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 rounded-xl shadow-xl text-white border border-cyan-400/50"
                    >
                      Rejouer
                    </motion.button>
                    <motion.button
                      onClick={() => setTimeLeft(30)}
                      whileHover={{ scale: 1.05, y: -2 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-8 py-3 bg-[#16213e]/70 rounded-xl border border-cyan-400/30 text-cyan-200"
                    >
                      Retour
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
