import { motion } from "motion/react";
import { Home, ScrollText, ShoppingBag, Sparkles, Palette, Gamepad2 } from "lucide-react";

interface NavigationProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

export function Navigation({ currentPage, onPageChange }: NavigationProps) {
  const navItems = [
    { id: "sanctuary", icon: Home, label: "Sanctuaire" },
    { id: "quests", icon: ScrollText, label: "Quêtes" },
    { id: "marketplace", icon: ShoppingBag, label: "Marché" },
    { id: "summoning", icon: Sparkles, label: "Invocation" },
    { id: "customization", icon: Palette, label: "Style" },
    { id: "minigame", icon: Gamepad2, label: "Jeux" },
  ];

  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-xl border-t border-purple-200/50 shadow-2xl shadow-purple-100/30"
    >
      <div className="max-w-6xl mx-auto px-4 py-3">
        <div className="flex justify-around items-center">
          {navItems.map((item) => (
            <motion.button
              key={item.id}
              onClick={() => onPageChange(item.id)}
              whileHover={{ scale: 1.1, y: -2 }}
              whileTap={{ scale: 0.9 }}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-2xl transition-all relative ${
                currentPage === item.id
                  ? 'text-purple-600'
                  : 'text-purple-400 hover:text-purple-600'
              }`}
            >
              {currentPage === item.id && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-purple-100/60 rounded-2xl shadow-lg shadow-purple-200/50"
                />
              )}
              <div className="relative">
                <item.icon className="w-6 h-6" />
                {currentPage === item.id && (
                  <motion.div
                    className="absolute -inset-2 bg-purple-300/30 rounded-full blur-lg -z-10"
                    animate={{
                      scale: [1, 1.2, 1],
                      opacity: [0.3, 0.6, 0.3],
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                )}
              </div>
              <span className="text-xs relative">{item.label}</span>
            </motion.button>
          ))}
        </div>
      </div>
    </motion.nav>
  );
}
