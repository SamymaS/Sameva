import { motion } from "motion/react";
import { Palette, Shirt, Crown, Sparkles, Eye, Home, X } from "lucide-react";
import { useState } from "react";

export function Customization() {
  const [selectedTab, setSelectedTab] = useState("avatar");
  const [selectedColor, setSelectedColor] = useState("#a78bca");

  const tabs = [
    { id: "avatar", label: "Avatar", icon: Eye },
    { id: "outfit", label: "Outfit", icon: Shirt },
    { id: "accessories", label: "Accessories", icon: Crown },
    { id: "aura", label: "Aura", icon: Sparkles },
    { id: "sanctuary", label: "Background", icon: Home },
  ];

  const colors = [
    "#a78bca", // soft purple
    "#daa5c0", // soft pink
    "#7ba5d6", // soft blue
    "#8ec9a8", // soft green
    "#e5b88a", // soft amber
    "#d19393", // soft red
    "#7ec4c4", // soft cyan
    "#b48fd1", // soft violet
  ];

  const hairStyles = [
    { id: 1, preview: "🎀" },
    { id: 2, preview: "💇" },
    { id: 3, preview: "👱" },
  ];

  const outfits = [
    { id: 1, name: "Robe Mystique", icon: "👘" },
    { id: 2, name: "Tenue Céleste", icon: "🧥" },
    { id: 3, name: "Cape Étoilée", icon: "🦺" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f0e8f0] via-[#e5dcec] to-[#dcd0e8] overflow-hidden relative">
      {/* Soft atmospheric glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-300/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-pink-300/20 rounded-full blur-[120px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-300/10 rounded-full blur-[140px]" />
      </div>

      {/* Header */}
      <div className="relative z-10 p-6 flex justify-between items-center">
        <h2 className="text-purple-900/70 text-center flex-1">
          CUSTOMIZE
        </h2>
        <button className="w-10 h-10 rounded-full bg-white/60 backdrop-blur-md border border-purple-200/50 flex items-center justify-center shadow-lg shadow-purple-100/30">
          <X className="w-5 h-5 text-purple-700" />
        </button>
      </div>

      {/* Main content area */}
      <div className="relative z-10 px-6 mt-6">
        <div className="max-w-4xl mx-auto">
          {/* Preview area with character */}
          <div className="bg-gradient-to-b from-[#d8cce0]/40 to-[#cfc0dc]/40 backdrop-blur-xl border border-white/50 rounded-[3rem] p-8 mb-6 shadow-2xl shadow-purple-200/40 relative overflow-hidden">
            {/* Soft background glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-300/30 rounded-full blur-[100px]" />
            
            <div className="relative flex gap-8">
              {/* Left side controls */}
              <div className="flex flex-col gap-3">
                <motion.button
                  whileHover={{ scale: 1.1, x: 4 }}
                  className="w-14 h-14 rounded-2xl bg-white/70 backdrop-blur-md border border-purple-200/50 flex items-center justify-center shadow-lg shadow-purple-100/40 text-2xl"
                >
                  👤
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1, x: 4 }}
                  className="w-14 h-14 rounded-2xl bg-white/70 backdrop-blur-md border border-purple-200/50 flex items-center justify-center shadow-lg shadow-purple-100/40 text-2xl"
                >
                  💇
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1, x: 4 }}
                  className="w-14 h-14 rounded-2xl bg-white/70 backdrop-blur-md border border-purple-200/50 flex items-center justify-center shadow-lg shadow-purple-100/40 text-2xl"
                >
                  🎨
                </motion.button>
              </div>

              {/* Center character preview */}
              <div className="flex-1 flex flex-col items-center justify-center">
                {/* Character with massive soft halo */}
                <motion.div
                  className="relative"
                  animate={{
                    y: [0, -10, 0],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  {/* Multiple layered halos */}
                  <div className="absolute inset-0 rounded-full blur-[120px] scale-[3]" style={{ backgroundColor: `${selectedColor}30` }} />
                  <div className="absolute inset-0 rounded-full blur-[80px] scale-[2.5]" style={{ backgroundColor: `${selectedColor}40` }} />
                  <div className="absolute inset-0 rounded-full blur-[60px] scale-[2]" style={{ backgroundColor: `${selectedColor}50` }} />
                  
                  {/* Character illustration placeholder */}
                  <div className="relative w-48 h-64 flex items-center justify-center">
                    <div className="text-8xl">🧙‍♀️</div>
                  </div>
                </motion.div>

                {/* Ethereal companion */}
                <motion.div
                  className="relative mt-8"
                  animate={{
                    y: [0, -8, 0],
                    opacity: [0.7, 1, 0.7],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                  }}
                >
                  <div className="absolute inset-0 bg-cyan-300/30 rounded-full blur-[40px] scale-[2]" />
                  <div className="text-5xl relative">🦊</div>
                </motion.div>
              </div>

              {/* Right side options */}
              <div className="flex flex-col gap-3">
                <motion.button
                  whileHover={{ scale: 1.1, x: -4 }}
                  className="w-32 h-32 rounded-3xl bg-white/70 backdrop-blur-md border border-purple-200/50 shadow-xl shadow-purple-100/40 flex flex-col items-center justify-center gap-2 text-purple-800"
                >
                  <div className="text-3xl">💇</div>
                  <span className="text-xs">HAIR</span>
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1, x: -4 }}
                  className="w-32 h-32 rounded-3xl bg-white/70 backdrop-blur-md border border-purple-200/50 shadow-xl shadow-purple-100/40 flex flex-col items-center justify-center gap-2 text-purple-800"
                >
                  <div className="text-3xl">👕</div>
                  <span className="text-xs">BODY</span>
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1, x: -4 }}
                  className="w-32 h-32 rounded-3xl bg-white/70 backdrop-blur-md border border-purple-200/50 shadow-xl shadow-purple-100/40 flex flex-col items-center justify-center gap-2 text-purple-800"
                >
                  <div className="text-3xl">🌅</div>
                  <span className="text-xs">BACKGROUND</span>
                </motion.button>
              </div>
            </div>

            {/* Color picker */}
            <div className="mt-8">
              <div className="flex gap-3 justify-center flex-wrap">
                {colors.map((color) => (
                  <motion.button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    whileHover={{ scale: 1.2, y: -4 }}
                    whileTap={{ scale: 0.9 }}
                    className={`w-12 h-12 rounded-full border-3 shadow-lg ${
                      selectedColor === color ? 'border-white scale-110' : 'border-white/50'
                    }`}
                    style={{ 
                      backgroundColor: color,
                      boxShadow: selectedColor === color ? `0 8px 24px ${color}60` : `0 4px 12px ${color}40`
                    }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Bottom options */}
          <div className="grid grid-cols-2 gap-6 mb-24">
            {/* Avatar section */}
            <div className="bg-white/60 backdrop-blur-md border border-purple-200/50 rounded-3xl p-6 shadow-xl shadow-purple-100/30">
              <h4 className="text-purple-900/80 mb-4 text-center">AVATAR</h4>
              <div className="grid grid-cols-3 gap-3">
                {[...Array(6)].map((_, idx) => (
                  <motion.button
                    key={idx}
                    whileHover={{ scale: 1.1, y: -4 }}
                    className="aspect-square rounded-2xl bg-gradient-to-br from-purple-100/80 to-pink-100/80 border border-purple-200/50 shadow-lg shadow-purple-100/40 flex items-center justify-center text-2xl"
                  >
                    {['👘', '🧥', '🦺', '💇', '👱', '🎀'][idx]}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Decor section */}
            <div className="bg-white/60 backdrop-blur-md border border-purple-200/50 rounded-3xl p-6 shadow-xl shadow-purple-100/30">
              <h4 className="text-purple-900/80 mb-4 text-center">DECOR</h4>
              <div className="grid grid-cols-2 gap-3">
                {[...Array(4)].map((_, idx) => (
                  <motion.button
                    key={idx}
                    whileHover={{ scale: 1.05, y: -4 }}
                    className="aspect-video rounded-2xl bg-gradient-to-br from-blue-100/80 to-purple-100/80 border border-blue-200/50 shadow-lg shadow-blue-100/40 flex items-center justify-center text-3xl relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent" />
                    {['🌅', '🌌', '🏰', '🌳'][idx]}
                  </motion.button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
