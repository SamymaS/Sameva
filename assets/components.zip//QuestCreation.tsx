import { motion } from "motion/react";
import { Plus, Target, Calendar, Star, Flame, Zap, Book } from "lucide-react";
import { useState } from "react";

export function QuestCreation() {
  const [selectedDifficulty, setSelectedDifficulty] = useState("medium");
  const [selectedCategory, setSelectedCategory] = useState("personal");

  const difficulties = [
    { id: "easy", label: "Facile", xp: "+50 XP", color: "from-green-200 to-emerald-200" },
    { id: "medium", label: "Moyenne", xp: "+100 XP", color: "from-yellow-200 to-orange-200" },
    { id: "hard", label: "Difficile", xp: "+200 XP", color: "from-red-200 to-pink-200" },
    { id: "epic", label: "Épique", xp: "+500 XP", color: "from-purple-200 to-indigo-200" },
  ];

  const categories = [
    { id: "personal", label: "Personnel", icon: Star },
    { id: "health", label: "Santé", icon: Flame },
    { id: "learning", label: "Apprentissage", icon: Book },
    { id: "work", label: "Travail", icon: Target },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#faf8f5] via-[#f5ede8] to-[#f0e5e0] overflow-hidden relative">
      {/* Soft texture overlay */}
      <div className="absolute inset-0 opacity-[0.03]">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }} />
      </div>

      {/* Soft floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-amber-300/20 rounded-full"
            animate={{
              y: ["100%", "-20%"],
              x: [Math.random() * 100 + "%", Math.random() * 100 + "%"],
              opacity: [0, 0.4, 0],
            }}
            transition={{
              duration: Math.random() * 5 + 4,
              repeat: Infinity,
              delay: Math.random() * 3,
            }}
            style={{
              left: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <div className="relative z-10 p-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <h2 className="text-amber-900/70">
            Parchemin des Quêtes
          </h2>
          <p className="text-amber-800/60 mt-2">Inscris ta nouvelle quête</p>
        </motion.div>
      </div>

      {/* Main parchment */}
      <div className="relative z-10 px-6 mt-6">
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white/70 backdrop-blur-xl border-2 border-amber-200/60 rounded-[3rem] p-8 shadow-2xl shadow-amber-200/40 max-w-2xl mx-auto relative overflow-hidden"
        >
          {/* Soft inner glow */}
          <div className="absolute inset-0 bg-gradient-to-br from-amber-100/40 to-orange-100/30 rounded-[3rem]" />

          <div className="relative">
            {/* Quest name input */}
            <div className="mb-6">
              <label className="block text-amber-900/80 mb-3 flex items-center gap-2">
                <Target className="w-5 h-5" />
                <span>Nom de la quête</span>
              </label>
              <input
                type="text"
                placeholder="Ex: Méditer pendant 20 minutes"
                className="w-full bg-white/70 backdrop-blur-sm border-2 border-amber-200/50 rounded-2xl px-5 py-3 text-amber-900 placeholder-amber-400/50 focus:border-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-200/50 transition-all shadow-lg shadow-amber-100/30"
              />
            </div>

            {/* Description */}
            <div className="mb-6">
              <label className="block text-amber-900/80 mb-3">Description</label>
              <textarea
                placeholder="Décris cette quête et pourquoi elle est importante pour toi..."
                rows={3}
                className="w-full bg-white/70 backdrop-blur-sm border-2 border-amber-200/50 rounded-2xl px-5 py-3 text-amber-900 placeholder-amber-400/50 focus:border-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-200/50 transition-all resize-none shadow-lg shadow-amber-100/30"
              />
            </div>

            {/* Category selection */}
            <div className="mb-6">
              <label className="block text-amber-900/80 mb-3">Catégorie</label>
              <div className="grid grid-cols-4 gap-3">
                {categories.map((cat) => (
                  <motion.button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    className={`p-4 rounded-2xl border-2 transition-all ${
                      selectedCategory === cat.id
                        ? 'bg-amber-200/60 border-amber-300/80 shadow-xl shadow-amber-200/50'
                        : 'bg-white/50 border-amber-200/30 hover:border-amber-300/50 shadow-lg shadow-amber-100/30'
                    }`}
                  >
                    <cat.icon className={`w-6 h-6 mx-auto mb-2 ${selectedCategory === cat.id ? 'text-amber-800' : 'text-amber-600/70'}`} />
                    <div className={`text-xs ${selectedCategory === cat.id ? 'text-amber-900' : 'text-amber-700/70'}`}>{cat.label}</div>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Difficulty */}
            <div className="mb-6">
              <label className="block text-amber-900/80 mb-3 flex items-center gap-2">
                <Zap className="w-5 h-5" />
                <span>Difficulté</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                {difficulties.map((diff) => (
                  <motion.button
                    key={diff.id}
                    onClick={() => setSelectedDifficulty(diff.id)}
                    whileHover={{ scale: 1.02, y: -2 }}
                    whileTap={{ scale: 0.98 }}
                    className={`p-4 rounded-2xl border-2 transition-all ${
                      selectedDifficulty === diff.id
                        ? `bg-gradient-to-br ${diff.color} border-white/60 shadow-xl`
                        : 'bg-white/50 border-amber-200/30 hover:border-amber-300/50 shadow-lg shadow-amber-100/30'
                    }`}
                  >
                    <div className={selectedDifficulty === diff.id ? 'text-gray-800' : 'text-amber-700/70'}>{diff.label}</div>
                    <div className={`text-xs mt-1 ${selectedDifficulty === diff.id ? 'text-gray-700/80' : 'text-amber-600/60'}`}>{diff.xp}</div>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Frequency */}
            <div className="mb-6">
              <label className="block text-amber-900/80 mb-3 flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                <span>Fréquence</span>
              </label>
              <div className="grid grid-cols-3 gap-3">
                {['Quotidien', 'Hebdomadaire', 'Une fois'].map((freq) => (
                  <motion.button
                    key={freq}
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-3 rounded-2xl bg-white/50 border-2 border-amber-200/30 hover:border-amber-300/50 transition-all text-amber-800/80 shadow-lg shadow-amber-100/30"
                  >
                    {freq}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Reward preview */}
            <div className="bg-gradient-to-br from-purple-100/60 to-pink-100/50 backdrop-blur-md border border-purple-200/50 rounded-3xl p-6 mb-6 shadow-lg shadow-purple-100/40">
              <h4 className="text-purple-900/80 mb-4">Récompenses estimées</h4>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="w-14 h-14 mx-auto mb-2 bg-gradient-to-br from-blue-200 to-cyan-200 rounded-full flex items-center justify-center shadow-xl shadow-blue-200/50 relative">
                    <div className="absolute inset-0 bg-blue-300/30 rounded-full blur-xl scale-150" />
                    <Star className="w-7 h-7 text-blue-600 relative" />
                  </div>
                  <div className="text-sm text-blue-800">+100 XP</div>
                </div>
                <div className="text-center">
                  <div className="w-14 h-14 mx-auto mb-2 bg-gradient-to-br from-amber-200 to-yellow-200 rounded-full flex items-center justify-center shadow-xl shadow-amber-200/50 relative">
                    <div className="absolute inset-0 bg-amber-300/30 rounded-full blur-xl scale-150" />
                    <span className="text-2xl relative">💰</span>
                  </div>
                  <div className="text-sm text-amber-800">+50 Or</div>
                </div>
                <div className="text-center">
                  <div className="w-14 h-14 mx-auto mb-2 bg-gradient-to-br from-purple-200 to-pink-200 rounded-full flex items-center justify-center shadow-xl shadow-purple-200/50 relative">
                    <div className="absolute inset-0 bg-purple-300/30 rounded-full blur-xl scale-150" />
                    <span className="text-2xl relative">✨</span>
                  </div>
                  <div className="text-sm text-purple-800">Objet rare</div>
                </div>
              </div>
            </div>

            {/* Create button */}
            <motion.button
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="w-full bg-gradient-to-r from-amber-200 to-orange-200 hover:from-amber-300 hover:to-orange-300 text-amber-900 py-4 rounded-2xl flex items-center justify-center gap-2 shadow-xl shadow-amber-200/50 transition-all border border-amber-300/50 backdrop-blur-md"
            >
              <Plus className="w-5 h-5" />
              <span>Créer la quête</span>
            </motion.button>
          </div>
        </motion.div>

        {/* Active quests preview */}
        <div className="mt-8 max-w-2xl mx-auto mb-24">
          <h4 className="text-amber-900/70 mb-4 px-2">Quêtes actives</h4>
          <div className="space-y-3">
            {[
              { name: "Lire 30 pages", progress: 65, color: "blue" },
              { name: "Courir 5km", progress: 100, color: "green" },
              { name: "Méditer 15min", progress: 30, color: "purple" },
            ].map((quest, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white/60 backdrop-blur-md border border-amber-200/40 rounded-2xl p-4 shadow-lg shadow-amber-100/30"
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="text-amber-900">{quest.name}</span>
                  <span className="text-xs text-amber-700/70">{quest.progress}%</span>
                </div>
                <div className="h-2 bg-white/70 rounded-full overflow-hidden shadow-inner">
                  <div
                    className={`h-full bg-gradient-to-r ${quest.color === 'blue' ? 'from-blue-300 to-cyan-300' : quest.color === 'green' ? 'from-green-300 to-emerald-300' : 'from-purple-300 to-pink-300'}`}
                    style={{ width: `${quest.progress}%` }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}