
  # MVP Sameva Development Guide

  This is a code bundle for MVP Sameva Development Guide. The original project is available at https://www.figma.com/design/BXl0u03e53LmMy5Rt2ATvd/MVP-Sameva-Development-Guide.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  